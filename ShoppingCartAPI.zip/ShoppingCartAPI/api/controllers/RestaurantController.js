'use strict';
var mongoose = require('mongoose');
var restaurant1 = mongoose.model('restaurant1');

exports.list_all_restaurants = function(req, res) {
  restaurant1.find({}, function(err, result) {
    if (err)
      {
        console.log("-------In error-----");
        res.send(err);
      }
      console.log("*********in Restaurant1",result);
      res.json(result);
  });

};

exports.get_a_restaurant = function(req, res) {
  console.log("******Restaurant id=",req.params.id);
  restaurant1.findById(req.params.id, function(err, restaurant) {
    if (err)
      {
        console.log("-------Error in get_a_restaurant-----");
        res.send(err);
      }
      console.log("*********in get_a_restaurant",restaurant);
      res.json(restaurant);
  });
};

  exports.justGet = function(req, res) {
    console.log("justGet");
  };
