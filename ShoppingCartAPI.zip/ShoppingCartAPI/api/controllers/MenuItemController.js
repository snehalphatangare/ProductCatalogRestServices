'use strict';
var mongoose = require('mongoose');

//var menuItems = mongoose.model('menuItems');
var menu = mongoose.model('menu1');


exports.list_all_menuItems = function(req, res) {
  menu.find(function(err, result) {
    if (err)
      {
        console.log("-------In error-----");
        res.send(err);
      }
      console.log("*********in get all menuItems",result.length);
      res.json(result);
  	});
  };

  exports.get_menuItems_inRestaurant = function(req, res) {
	  //console.log("******MenuItem id=",req.params.id);
	  menu.find({restaurant_id:req.params.id}, function(err, menuItem) {
	    if (err)
	      {
	        console.log("-------Error in get_a_menuItem-----");
	        res.send(err);
	      }
	      console.log("*********in get_a_menuItem",menuItem);
	      res.json(menuItem);
  		});

	};

