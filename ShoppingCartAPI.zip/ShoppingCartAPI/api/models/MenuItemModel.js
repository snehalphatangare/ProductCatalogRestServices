var mongoose = require('mongoose');

var menu = new mongoose.Schema({
  _id: { type: String },
  restaurant_id: String,
  name: String,
  description: String,
  price: Number,
  category: String,
  subCategory: String
});

module.exports =mongoose.model('menu1', menu);
